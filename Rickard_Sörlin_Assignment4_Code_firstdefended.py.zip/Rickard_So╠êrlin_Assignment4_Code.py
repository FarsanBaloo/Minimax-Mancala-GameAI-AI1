import random
import socket
import numpy as np
import time
from multiprocessing.pool import ThreadPool
import os



def receive(socket):
    msg = ''.encode()

    try:
        data = socket.recv(1024)
        msg += data
    except:
        pass
    return msg.decode()


def send(socket, msg):
    socket.sendall(msg.encode())


def initialstate(data):
    """ Function handels the initialstate for the game and returns the boardstate """

    boardstate = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    i = 0
    j = 1
    while i <= 13:
        boardstate[i] = int(data[j]) * 10 + int(data[j + 1])
        i += 1
        j += 2
    return boardstate


def terminaltest(data):
    if data == 'e':
        print("The game has ended")
        return True
    return False


def cutofftest(depth):
    """ Function handels the limit of the search depth """

    if depth == 3:
        return True
    return False


def actions(boardstate,player1):
    """ Function handels the check of the legal moves in current state of the Mancala game and return it in a list """

    legalmoves = []

    if player1:
        for i in range(0, 6):
            if boardstate[i] > 0:
                legalmoves.append(i)
    else:
        for i in range(7, 13):
            if boardstate[i] > 0:
                legalmoves.append(i)


    return legalmoves


def result(boardstate, action, player1):
    """ Function handels Mancala game rules that lets the Minmax algorithm to explore the diffrent game states
    and pick the best legal move according to evaluation function"""

    boardstate = boardstate.copy()

    # Take the marbles from the chosen hole to move (action)
    marbels = boardstate[action]
    boardstate[action] = 0
    currenthole = action

    # While having marbels in hand move to next hole and place on in each
    while marbels > 0:
        # keep counting to keep track where we are
        currenthole = (currenthole + 1) % len(boardstate)

        # If at the opponents Mancala hole jump over it dont give him my precious marbels and move to next hole
        if player1 and currenthole == 13:
            continue

        elif not player1 and currenthole == 6:
            continue

        # Put a marble in currenthole
        boardstate[currenthole] += 1
        marbels -= 1

    # Check if player got a extra turn and landed in there own Mancala
    if player1 and currenthole == 6:
        return boardstate, player1

    if not player1 and currenthole == 13:
        return boardstate, player1

    # Check if player placed his last marbel in a empty hole on his side
    elif boardstate[currenthole] == 1 and ((player1 and 0 <= currenthole <= 5)
                                           or (not player1 and 7 <= currenthole <= 12)):

        # Calculate what hole number it is for the opposite hole that opponent has
        oppositehole = 12 - currenthole

        # Check if there is any marbels in the opponents hole for current boardstate
        if boardstate[oppositehole] > 0:
            # Grab the stones from the opposite hole from opponent
            capturedmarbels = boardstate[oppositehole]
            # Empty opponents hole and my hole
            boardstate[currenthole] = 0
            boardstate[oppositehole] = 0
            # Place the captured marbels and the last played marble secure in the Mancala
            if player1:
                boardstate[6] += capturedmarbels + 1
            else:
                boardstate[13] += capturedmarbels + 1

    # next opposite player turn
    return boardstate, not player1


def alphabetasearch(boardstate, player1, alpha, beta):
    """ Function handels the Min & Max Alpha Beta search recursive algorithm """

    v = -np.inf
    bestaction = None

    for action in actions(boardstate, player1):
        newv = maxvalue(result(boardstate, action, player1)[0], alpha, beta, 1, not player1)
        if newv > v:
            v = newv
            bestaction = action
        alpha = max(alpha, v)

    if bestaction is None:
        # Check again if there is any legalmove instead of returning none and occur problem on server side
        legalmoves = actions(boardstate, player1)
        bestaction = random.choice(legalmoves)
    return bestaction + 1, v


def maxvalue(boardstate, alpha, beta, depth, player1):
    """ Function handels the max value algorithm functionality"""

    if cutofftest(depth):
        return evaluate(boardstate)

    v = -np.inf
    for action in actions(boardstate, player1):
        newboardstate, nextplayer = result(boardstate, action, player1)
        v = max(v, minvalue(newboardstate, alpha, beta, depth + 1, player1))
        if v >= beta:
            return v
        alpha = max(alpha, v)
    return v


def minvalue(boardstate, alpha, beta, depth, player1):
    """ Function handels the minvalue algorithm functionality """

    if cutofftest(depth):
        return evaluate(boardstate)

    v = np.inf
    for action in actions(boardstate, player1):
        newboardstate, nextplayer = result(boardstate, action, player1)
        v = min(v, maxvalue(newboardstate, alpha, beta, depth + 1, player1))
        if v <= alpha:
            return v
        beta = min(beta, v)
    return v


def evaluate(boardstate):
    """ Function handels the Heuristic evaluation of the states of the Mancala game to guide tha algorithm  """

    # Nr 1 - Calculate the score differens in players Mancala
    # by checking amount of marbels each player has in there Mancala
    playermancala = boardstate[6]
    opponentmancala = boardstate[13]

    scoreweight = 1.0
    scorediffrens = scoreweight * (playermancala - opponentmancala)

    # Nr 2 gain score by stealing from opponent can give great advantage and should be prioritezed
    # Calculate my AI player possebilities to steal from the opponent want it to be positiv
    playersteal = 0
    for i in range(6):
        if boardstate[i] == 0 and boardstate[12-i] > 0:
            playersteal += 1

    # Calculate score for opponents possebilities to steal from my holes want it to be zero
    opponentsteal = 0
    for i in range(7, 13):
        if boardstate[i] == 0 and boardstate[12-i] > 0:
            opponentsteal =+ 1

    # Highere player stealscore "My AI bot" give posoitive value else negative
    stealpotential = playersteal - opponentsteal
    stealweight = 3.0
    scoresteal = stealweight * stealpotential

    # Nr 3 - Count the amount of marbels each player has on there side is good to know for "starwing" the opponent like
    # getA5Player at the end all marbels on player side is allowed to count to score and can gain alot of it
    playermarbels = sum(boardstate[:6])
    opponentmarbels = sum(boardstate[7:13])
    marbelsweight = 0.3
    marbelsdiffrens = marbelsweight * (playermarbels - opponentmarbels)

    # Nr 4 Calculate amount of empty holes for each player if higher then opponent it open ups for stealing ;O)
    playeremptyholes = 0
    for i in range(6):
        if boardstate[i] == 0:
            playeremptyholes +=1

    opponentemptyholes = 0
    for i in range(7,13):
        if boardstate[i] == 0:
            playeremptyholes += 1

    emptyholesweight = 0.4
    emptyholesdiff = emptyholesweight * (playeremptyholes - opponentemptyholes)

    # Doing the calculation of the heuristic values of current state
    score = scorediffrens + scoresteal + marbelsdiffrens + emptyholesdiff

    return int(score)


# VARIABLES
playerName = 'Rickard_Sörlin'
host = '127.0.0.1'
port = 30000
clientsocket = socket.socket()
pool = ThreadPool(processes=1)
gameEnd = False
MAX_RESPONSE_TIME = 5

print('The player: ' + playerName + ' starts!')
print("The Mancala server is starting up ")
os.startfile(r"Mancala.exe")

while True:
    try:
        clientsocket.connect((host, port))
        print('The player: ' + playerName + ' connected and ready!')

        os.startfile(r"getA3Player.exe")

        break
    except:
        continue

data = []
board_state = []

while not terminaltest(data):

    async_result = pool.apply_async(receive, (clientsocket,))
    start_time = time.time()
    current_time = 0
    received = 0
    data = []

    while received == 0 and current_time < MAX_RESPONSE_TIME:
        if async_result.ready():
            data = async_result.get()
            received = 1
        current_time = time.time() - start_time

    if received == 0:
        print('No response in ' + str(MAX_RESPONSE_TIME) + ' sec')
        gameEnd = 1

    if data == 'N':
        send(clientsocket, playerName)

    if len(data) > 1:
        boardstate = initialstate(data)

        move, V = alphabetasearch(boardstate, True, -np.inf, np.inf)

        print("Moved stones from hole:", move)
        print("Evaluation score for current move:", V)
        send(clientsocket, str(move))


